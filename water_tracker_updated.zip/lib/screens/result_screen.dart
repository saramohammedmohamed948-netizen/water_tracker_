import 'package:flutter/material.dart';

import '../contants/app_colors.dart';
import '../utils/water_calculator.dart';
import '../widgets/bottom_button.dart';

class ResultScreen extends StatelessWidget {
  final double recommendedLitres;
  final int bodyWeightKg;
  final int userAgeYears;
  final double dailyActivityHours;
  final String gender;

  const ResultScreen({
    super.key,
    required this.recommendedLitres,
    required this.bodyWeightKg,
    required this.userAgeYears,
    required this.dailyActivityHours,
    required this.gender,
  });

  @override
  Widget build(BuildContext context) {
    final String hydrationGuidance = WaterCalculator.getGuidanceText(
      recommendedLitres,
    );
    // نسبة تقريبية للمؤشر الدائري (بحد أقصى 5 لتر)
    final double progressFraction = (recommendedLitres / 5.0).clamp(0.1, 1.0);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: const Text(
          'Your Daily Water Intake',
          style: TextStyle(
            color: AppColors.textPrimary,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 2. بطاقة النتيجة الرئيسية مع مؤشر دائري
              Container(
                padding: const EdgeInsets.symmetric(
                  vertical: 28,
                  horizontal: 20,
                ),
                decoration: BoxDecoration(
                  color: AppColors.activeCard,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.primaryTeal, width: 1.8),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primaryTeal.withOpacity(0.15),
                      blurRadius: 16,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        SizedBox(
                          width: 150,
                          height: 150,
                          child: CircularProgressIndicator(
                            value: progressFraction,
                            strokeWidth: 8,
                            backgroundColor: AppColors.inactiveCard,
                            valueColor: const AlwaysStoppedAnimation<Color>(
                              AppColors.primaryTeal,
                            ),
                          ),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.water_drop,
                              color: AppColors.primaryTeal,
                              size: 32,
                            ),
                            const SizedBox(height: 6),
                            Text(
                              '${recommendedLitres.toStringAsFixed(2)} L',
                              style: const TextStyle(
                                color: AppColors.primaryTeal,
                                fontSize: 28,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const Text(
                              'per Day',
                              style: TextStyle(
                                color: AppColors.textSecondary,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    const Text(
                      'Estimated value\n(educational formula)',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // 3. توضيح أن القيمة تقديرية وليست نصيحة طبية
              Container(
                padding: const EdgeInsets.symmetric(
                  vertical: 14,
                  horizontal: 16,
                ),
                decoration: BoxDecoration(
                  color: AppColors.inactiveCard,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.white10),
                ),
                child: const Row(
                  children: [
                    Icon(
                      Icons.info_outline,
                      color: AppColors.primaryTeal,
                      size: 22,
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Educational estimate only — not medical advice.',
                        style: TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 13.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 14),

              // 4. النص التوجيهي المبسط
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.inactiveCard,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.white10),
                ),
                child: Text(
                  hydrationGuidance,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 14.5,
                    height: 1.5,
                  ),
                ),
              ),

              const SizedBox(height: 14),

              // 5. ملخص المدخلات
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.inactiveCard,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.white10),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _SummaryItem(
                          label: 'Weight',
                          value: '$bodyWeightKg kg',
                        ),
                        _SummaryItem(
                          label: 'Activity',
                          value:
                              '${dailyActivityHours % 1 == 0 ? dailyActivityHours.toInt() : dailyActivityHours.toStringAsFixed(1)} h',
                        ),
                      ],
                    ),
                    const Divider(color: Colors.white12, height: 22),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _SummaryItem(
                          label: 'Age',
                          value: '$userAgeYears years',
                        ),
                        _SummaryItem(label: 'Gender', value: gender),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // 6. زر العودة Re-calculate
              BottomButton(
                label: 'Re-calculate',
                leadingIcon: Icons.refresh,
                onTap: () => Navigator.pop(context),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SummaryItem extends StatelessWidget {
  final String label;
  final String value;

  const _SummaryItem({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          '$label: ',
          style: const TextStyle(color: AppColors.textSecondary, fontSize: 14),
        ),
        Text(
          value,
          style: const TextStyle(
            color: AppColors.textPrimary,
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}
