class WaterCalculator {
  static double calculateWaterLitres({
    required int bodyWeightKg,
    required double dailyActivityHours,
  }) {
    final double baseWaterMl = bodyWeightKg * 35.0; // base need
    final double activityWaterMl = dailyActivityHours * 250.0; // activity extra
    final double totalWaterMl = baseWaterMl + activityWaterMl; // total in ml
    return totalWaterMl / 1000.0; // convert to litres
  }

  static String getGuidanceText(double recommendedLitres) {
    if (recommendedLitres < 2.0) {
      return 'Relatively low estimate under this educational formula. You can spread your water drinking throughout the day.';
    } else if (recommendedLitres <= 3.0) {
      return 'Moderate estimate under this educational formula. Try to spread your drinking over intervals during the day.';
    } else {
      return 'Relatively high estimate due to weight or activity hours. Actual needs vary from person to person, and you can consult a specialist if needed.';
    }
  }
}
